# Neighbourhood Map Project

This map shows the popular places to visit in my city-DEHRADUN.


# Languages Used

* HTML
* CSS
* JavaScript

# How to run the Project

1. Open the `index.html` file in the folder.

2. And enter or select the place which you want to find.

# APIs Used

* [Foursquare API](https://foursquare.com/developers/register)
* [Google Maps API](https://developers.google.com/maps/)
this app uses personal API Key.

# References

* https://developer.foursquare.com/docs/api/venues/search parameters for fetching FourSquare details.

* http://esprima.org/demo/validate.html for syntax error detection.

# KeySkills
This project shows my knowledge on AJAX , google Map API ,  FourSquare API , filtering using Knockout and knockout util functions. This project uses Udacity tutorials.
