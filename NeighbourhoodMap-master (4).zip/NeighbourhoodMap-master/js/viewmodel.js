//viewmodel for the project
var displayMarker = function() // variable to display the markers .
 {

    var self = this;
    self.arrayLocations = ko.observableArray([]);  // Array[] to store the locations
    self.query = ko.observable('');


    places.forEach(function(item)   // Push each location in arrayLocations[]
     {
        self.arrayLocations.push(new Location(item));
    });


    self.searchResults = ko.computed(function()  // function to search from the locations
    {
        var filt = self.query().toLowerCase();

        // For filter Markers
        for (var l = 0; l < self.arrayLocations().length; l++)
        {
            if (self.arrayLocations()[l].name().toLowerCase().indexOf(filt) > -1) //change into lowercase and then search
             {
                for (var m = 0; m < markers.length; m++)
                {
                    if (self.arrayLocations()[l].name() == markers[m].title)
                     {
                        markers[m].setVisible(true);
                    }
                }
            } else {
                for (var n = 0; n < markers.length; n++)
                {
                    if (self.arrayLocations()[l].name() == markers[n].title)
                    {
                        markers[n].setVisible(false);
                    }
                }
            }
        }

        // for Filter List
        if (!filt)
        {
            return self.arrayLocations();
        } else {
            return ko.utils.arrayFilter(self.arrayLocations(), function(item)
             {
                return item.name().toLowerCase().indexOf(filt) > -1;
            });
        }
    });

        // Indicates the current location on selecting
    self.presentLocation = ko.observable(self.arrayLocations()[0]);

    self.setLocation = function(selectedLocation)
    {
        self.presentLocation(selectedLocation);
        console.log(selectedLocation.name());
        for (var t = 0; t < markers.length; t++)
         {
            if (selectedLocation.name() == markers[t].title)
             {
                google.maps.event.trigger(markers[t], 'click');
            }
        }
    };
};

ko.applyBindings(new displayMarker());
