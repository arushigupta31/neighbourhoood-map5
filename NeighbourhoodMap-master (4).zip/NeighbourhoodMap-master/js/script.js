//  Maps API
var map;

var markers = [];

// Generate an error when the Map does not load completely.
function googleError()
 {
    document.getElementById('map').innerHTML = "Map is unable to load";
}

// Contains locations of different places on the map.
var places = [
  {name :"Clock Tower",loc: {lat: 30.3243 ,lng: 78.0418},
  venue_id: "4f58d184e4b003e668ac14c3"
},
  {name :"Robber's Cave",loc: {lat: 30.375982 ,lng: 78.060173},
  venue_id: "56595bd0498e715f633e2ddd"
},
  {name :"Tapkeshwar temple",loc: {lat: 30.3573 ,lng: 78.0167},
   venue_id: "516fc256e4b03bca88777ab4"
},
  {name :"Orchard",loc: {lat: 30.3898 ,lng: 78.0946},
  venue_id: "4ce26c7df8a4a143a44bf0bc"
},
  {name :"pacific mall",loc: {lat: 30.3664 ,lng: 78.0703},
  venue_id: "51cc0ebd498e393864d3bcc4"
},
  {name :"Malasi deer park",loc: {lat: 30.3897 ,lng: 78.0747},
  venue_id: "4efaeecb775b54cdb786e2e9"
},
  {name :"Forest Research Institute",loc: {lat: 30.343769 ,lng: 77.999559},
  venue_id: "56c95d90cd10173286d99b0c"
},
  ];
// This function helps in creating the locations
function Location(data)
{
    var self = this;
    self.name = ko.observable(data.name);
    self.location = ko.observable(data.location);
    this.venue_id = ko.observable(data.venue_id);
}


function initMap()
 {
//setting map type and map area.
    var location = new google.maps.LatLng(30.3165, 78.0322);

        var mapCanvas = document.getElementById('map');
        var mapOptions = {
            center: location,
            zoom: 15,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        }
        var map = new google.maps.Map(mapCanvas, mapOptions)
//setting an image for our markers.
    var markerImage = 'marker.png';


    var largeInfowindow = new google.maps.InfoWindow();
    var bounds = new google.maps.LatLngBounds();
    // Creates an array of markers for the places array to initialize on
  for (var i = 0; i < places.length; i++)
   {
        // Gets position and title from the places[]
        var position = places[i].loc;
        var title = places[i].name;
        // Creates a marker for each location
        var marker = new google.maps.Marker
        ({
            map: map,
            position: position,
            title: title,
            animation: google.maps.Animation.DROP,
            icon: markerImage,
        });

        // Push the marker to an array of markers
        markers.push(marker);
        // Creates a window that opens up on the clicking the marker.
        marker.addListener('click', function()
        {
           populateInfoWindow(this, largeInfowindow);
           addApi(venue);
        });

    bounds.extend(markers[i].position);
    }
    // Extend the boundaries of the map for each marker
    map.fitBounds(bounds);
}

      // This function populates the infowindow when the marker is clicked. We'll only allow
      // one infowindow which will open at the marker that is clicked, and populate based
      // on that markers position.
    function populateInfoWindow(marker, infowindow)
    {

        // Checks if infowindow is already opened on the marker.
        if (infowindow.marker != marker)
        {

            infowindow.marker = marker;

            // For FourSquare Ajax
            // Indicates the URL for FOURSQUARE API
            //var fourSquareURL = 'https://api.foursquare.com/v2/venues/search?ll=' + marker.position.lat() + ',' + marker.position.lng() + '&query=' + marker.title + '&client_id=N05OS114UA5GMUFD4WCAFS450Y1F5XLNFCQRQA2KRGKFCN4K&client_secret=B0WQMMJZ4NCN3T0DHZRTFUUDEBJFTRDWMHNLHDJEXEXO33N4&v=20171030';
            var fsUrl = "https://api.foursquare.com/v2/venues/",
                fsClient_id = "client_id=N05OS114UA5GMUFD4WCAFS450Y1F5XLNFCQRQA2KRGKFCN4K",
                fsClient_secret = "&client_secret=B0WQMMJZ4NCN3T0DHZRTFUUDEBJFTRDWMHNLHDJEXEXO33N4",
                fsVersion = "&v=20171026";


            var fourSquareRequestTimeOut = setTimeout(function() {
                infowindow.setContent('<div>' + marker.title + '</div>' + '<div>Failed to get information from FourSquare</div>');
                toggleBounce(marker);
                infowindow.open(map, marker);
            },
            4300);

           var addApi = function(venue){
            $.ajax
            ({
               venueID: selectedLocation.venue_id()+"/?",
                url: fsUrl + venueID + fsClient_id + fsClient_secret + fsVersion,
                method: GET,
                dataType: 'jsonp',
                success: function(response)
                {
                    var fResult = response.response.venue[0] || "";
                   //address of the selected place
                    var address = fResult.location.formattedAddress;
                    if (address === undefined)
                    {
                        address = "Not available on FourSquare";
                    }
                   //contact number of the selected place
                    var phoneNo = fResult.contact.formattedPhone;
                    if (phoneNo === undefined)
                    {
                        phoneNo = "Not available on FourSquare";
                    }
                    //opening hours
                    var hours = fResult.hours;
                    if (hours === undefined)
                    {
                      hours = "Not available on Foursquare";
                    }
                    //site for the place
                    var url = fResult.url;
                    if (url === undefined)
                    {
                        url = "Not available on FourSquare";
                    }

                    infowindow.setContent('<div>' + marker.title + '</div>' + '<div>Contact details from FourSquare:</div>' + '<div>Phone: ' + phoneNo + '</div>' + '<div>Hours: ' + hours + '</div>' + '<div>Website: '+'<a href="' + url + '">' + url + '</a>' + '</div>' + '<div>Address: ' + address + '</div>');

                    toggleBounce(marker);
                    infowindow.open(map, marker);
                    //to stop the execution
                    clearTimeout(fourSquareRequestTimeOut);
                }
            });

            // to make sure infowindow is cleared once the marker is closed.
            infowindow.addListener('closeclick', function()
            {
                infowindow.marker = null;
                marker.setAnimation(null);
            });
        }
    }


    // This Function gives animation to the markers (here, it is a DROP)
    function toggleBounce(marker)
    {
        if (marker.getAnimation() !== null)
        {
            marker.setAnimation(null);
        } else {
            marker.setAnimation(google.maps.Animation.DROP);

            // Set the timeout on DROP to 500ms so that the marker DROPS only once when clicked
            setTimeout(function()
            {
                marker.setAnimation(null);
            }, 500);
        }
    }
 }
